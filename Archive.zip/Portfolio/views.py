from django.shortcuts import render
from .models import Project, Skill, Tool

def portfolio_view(request):
    projects = Project.objects.all()
    skills = Skill.objects.all()
    tools = Tool.objects.all()
    context = {
        'projects': projects,
        'skills': skills,
        'tools': tools
    }
    return render(request, 'portfolio/portfolio.html', context)



from django.http import HttpResponse

def om(request):
    domain_owner = 'HexaCore by Om Gajipara'
    return HttpResponse(f"This domain is under: {domain_owner}")










